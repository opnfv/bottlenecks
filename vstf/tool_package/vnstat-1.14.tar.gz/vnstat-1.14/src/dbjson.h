#ifndef DBJSON_H
#define DBJSON_H

void showjson(int dbcount, char mode);
void jsondays(void);
void jsonmonths(void);
void jsontops(void);
void jsonhours(void);
void jsondate(time_t *date, int type);
void jsonheader(void);
void jsonfooter(void);

#endif
