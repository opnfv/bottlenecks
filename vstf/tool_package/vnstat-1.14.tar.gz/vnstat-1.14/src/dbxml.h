#ifndef DBXML_H
#define DBXML_H

void showxml(char mode);
void xmldays(void);
void xmlmonths(void);
void xmltops(void);
void xmlhours(void);
void xmldate(time_t *date, int type);
void xmlheader(void);
void xmlfooter(void);

#endif
