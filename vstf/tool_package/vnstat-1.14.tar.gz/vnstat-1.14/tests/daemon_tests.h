#ifndef DAEMON_TESTS_H
#define DAEMON_TESTS_H

void add_daemon_tests(Suite *s);
int cachegetname(const char *iface);

#endif
